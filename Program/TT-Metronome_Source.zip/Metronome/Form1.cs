﻿using System;
using System.Collections.Generic;
using System.Media;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace Metronome
{
    public partial class MainForm : Form
    {
        SoundPlayer theClick;
        string soundFileName = "click.wav";
        Queue<long> twentyQueue = new Queue<long>(19);
        Queue<long> fiveQueue = new Queue<long>(4);
        long lastTick = 0;
        long tickDistance;
        long tick5Distance;
        long tick20Distance;
        float theTempo;

        private ManualResetEvent stopClick = new ManualResetEvent(false);
        private Thread aThread;

        public MainForm()
        {
            InitializeComponent();
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }


        private void MainForm_Load(object sender, EventArgs e)
        {
            // when the form is first loaded
            
            try
            {
                theClick = new SoundPlayer(soundFileName);
                theClick.Load();
            }
            catch
            {
                MessageBox.Show(String.Format("Error opening sound file {0}", soundFileName));
                // load other sound file name instead?
            }

            stopButton.Enabled = false;
            useBPMTempoToolStripMenuItem.Enabled = false;
            useBPM5TempoToolStripMenuItem.Enabled = false;
            useBPM20TempoToolStripMenuItem.Enabled = false;
            stopToolStripMenuItem.Enabled = false;
            // manTempo.Text = "120.0"; // changeable, but default to something that's relatively common
        }

        // Tap tempo
        //
        // BPM: find time between last two 
        //
        // BPM (5): once fiveQueue is full,
        // 1) compare new time with the first time and divide by 5 for average
        // 2) pop the oldest time out
        // 3) push the newest time in
        //
        // BPM (20): once twentyQueue has at least 19, change divide by 5 to divide by 20

        private void Tap_Click(object sender, EventArgs e)
        {
            long newClick = DateTime.Now.Ticks;
            // 10M ticks = one second, actually quite accurate
            

            if (lastTick == 0) // only true if just starting
            {
                lastTick = newClick;
            }
            else
            {
                tickDistance = newClick - lastTick;
                textBPM.Text = string.Format("{0}", 6.0e8f/tickDistance); //one beat difference between ticks
                useBPMTempoToolStripMenuItem.Enabled = true;

                if (fiveQueue.Count < 4)
                {
                    fiveQueue.Enqueue(newClick);
                }
                else
                {
                    useBPM5TempoToolStripMenuItem.Enabled = true;
                    tick5Distance = newClick - fiveQueue.Peek();
                    fiveQueue.Dequeue();
                    textBPM5.Text = string.Format("{0}", 2.4e9f/tick5Distance);
                    //four beat difference between beginning and end
                    fiveQueue.Enqueue(newClick);
                }

                if (twentyQueue.Count < 19)
                {
                    twentyQueue.Enqueue(newClick);
                }
                else
                {
                    useBPM20TempoToolStripMenuItem.Enabled = true;
                    tick20Distance = newClick - twentyQueue.Peek();
                    twentyQueue.Dequeue();
                    textBPM20.Text = string.Format("{0}", 1.14e10f/tick20Distance);
                    twentyQueue.Enqueue(newClick);
                }

                lastTick = newClick;
            }
        }

        private void Tap_KeyDown(object sender, KeyEventArgs e)
        {
            // should do the same thing as Tap_Click
        }

        // end Tap

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About abtBox = new About();
            abtBox.Show();
        }
        

        private void MetClick_Click(object sender, EventArgs e)
        {
            // go through error checking; if it checks out, disable the buttons.

            // if the manual tempo box has input that is numeric, play clicks at the tempo given
            // if the manual tempo box has invalid input, make a pop-up that says that input is not valid
            // if the manual tempo box has no input:
            //     if the BPM box has nothing in it, do nothing (actually potentially disable clicking while all empty)
            //     if the BPM box has something, use the tempo text in the BPM box
            // it'll have to use a MessageBox

            // maybe do this in another function?
            if (manTempo.Text != "")
            {
                try
                {
                    theTempo = Convert.ToSingle(manTempo.Text);
                }
                catch (InvalidCastException)
                {
                    MessageBox.Show("Cannot cast to float; make sure that input is numeric!", "Input Error");
                    return;
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message, "Error");
                    return;
                }
            }
            else if (textBPM.Text != "")
            {
                theTempo = Convert.ToSingle(textBPM.Text); //this is guaranteed to work
                manTempo.Text = theTempo.ToString();
            }
            else
            {
                MessageBox.Show("No valid input; either use tap function or manually input a decimal number", "Input Error");
                return;
            }

            //
            MetClick.Enabled = false;
            stopButton.Enabled = true;
            stopToolStripMenuItem.Enabled = true;
            playToolStripMenuItem.Enabled = false;
            speedLabel.Text = theTempo.ToString();

            // are these if/else statements redundant?
            if (aThread == null)
            {
                aThread = new Thread(new ThreadStart(clicky));
                aThread.Start();
            }
            if (!aThread.IsAlive)
            {
                aThread = new Thread(new ThreadStart(clicky));
                // var mb = MessageBox.Show(aThread.ThreadState.ToString());
                aThread.Start();
                // mb = MessageBox.Show(aThread.ThreadState.ToString());
            }
        }
        
        private void clicky()
        {
            int interval = Convert.ToInt32(60000.0 / theTempo); //numerator in ms; denominator is BPM
            stopClick.Reset();
            while (!stopClick.WaitOne(1, false))
            {
                theClick.Play();
                Thread.Sleep(interval);
            }
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            stopClick.Set();
            theClick.Stop();
            aThread.Join();
            speedLabel.Text = "N/A";
            stopButton.Enabled = false;
            MetClick.Enabled = true;
            playToolStripMenuItem.Enabled = true;
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // clear everything
            speedLabel.Text = "N/A";
            textBPM.Text = "";
            textBPM5.Text = "";
            textBPM20.Text = "";
            manTempo.Text = "";
            lastTick = 0; //reset this too

            // clear queues
            twentyQueue.Clear();
            fiveQueue.Clear();

            stopButton.Enabled = false;
            MetClick.Enabled = true;
            useBPMTempoToolStripMenuItem.Enabled = false;
            useBPM5TempoToolStripMenuItem.Enabled = false;
            useBPM20TempoToolStripMenuItem.Enabled = false;
            stopClick.Set();
            theClick.Stop();
        }

        private void useBPMTempoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MetClick.Enabled)
            {
                manTempo.Text = textBPM.Text;
                MetClick_Click(sender, e);
            }
        }

        private void useBPM5TempoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MetClick.Enabled)
            {
                manTempo.Text = textBPM5.Text;
                MetClick_Click(sender, e);
            }
        }

        private void useBPM20TempoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MetClick.Enabled)
            {
                manTempo.Text = textBPM20.Text;
                MetClick_Click(sender, e);
            }
        }

        private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void playToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MetClick_Click(sender, e);
        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            stopButton_Click(sender, e);
        }
    }
}
